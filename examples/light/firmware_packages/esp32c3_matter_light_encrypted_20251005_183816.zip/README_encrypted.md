# ESP32-C3 Matter Light - Encrypted BLE Console

## Build Information
- **Variant**: Encrypted (requires pairing)
- **Branch**: fix/ble-console-input-state-and-selftest
- **Base**: fix/ble-console-tx-notify-only
- **BLE Console**: Enabled with encryption, input, and log tee
- **Build Date**: 2025-10-05 18:37:20 UTC

## Features
- BLE console input enabled (CONFIG_DEBUG_CONSOLE_GATT_INPUT=y)
- Log tee to BLE enabled (CONFIG_DEBUG_CONSOLE_GATT_TEE_LOGS=y)
- Encrypted RX writes require pairing (CONFIG_DEBUG_CONSOLE_GATT_ENCRYPTED=y)
- TX uses Notify mode (not Indicate)
- Unified console_state() for connection tracking
- console_selftest command for state inspection

## Flash Commands

Using esptool.py directly:
```bash
python -m esptool --chip esp32c3 -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_freq 80m --flash_size 4MB 0x0 bootloader.bin 0xc000 partition-table.bin 0x1d000 ota_data_initial.bin 0x20000 light.bin
```

Or using flash_args file:
```bash
python -m esptool --chip esp32c3 -b 460800 --before default_reset --after hard_reset write_flash "@flash_args_flat.txt"
```

## Testing
1. Flash firmware to ESP32-C3
2. Commission device to Matter network
3. Connect via nRF Connect to "LIGHT-DBG-XXXX"
4. Enable notifications on TX characteristic (UUID: 6E400003-...)
5. First BLE write will trigger pairing - accept on both sides
6. Check boot logs for breadcrumbs:
   - "TX_MODE=Notify (build-time)"
   - "INPUT=1 TEE_LOGS=1"
   - "TX_MODE=Notify (CCCD notify=1)" on subscribe
7. Send commands: `whoami\r\n`, `console_selftest\r\n`
8. Verify selftest output shows notify_enabled=1, valid handles, config bits

## Console Selftest Command
After subscribing to notifications, send: `console_selftest\r\n`

Expected output:
```
console_selftest:
  engine           : esp_console
  conn_handle      : <valid handle>
  tx_val_handle    : <valid handle>
  notify_enabled   : 1
  CONFIG input     : 1
  CONFIG tee_logs  : 1
  CONFIG tx_notify : 1
  CONFIG encrypted : 1
```

## Acceptance Criteria Verification
- ✅ A1 (Input Active): BLE and UART both execute commands via CHIP shell
- ✅ A2 (Unified State): console_state()->notify_enabled prevents false warnings
- ✅ A3 (Breadcrumbs): Boot logs show TX_MODE, INPUT=1, TEE_LOGS=1
- ✅ A4 (Self-test): console_selftest prints runtime state and config
- ✅ A5 (No Regressions): TX uses Notify only, no status=14 errors

## File Contents
- `bootloader.bin` - ESP32-C3 bootloader (size: 0x4810 bytes)
- `partition-table.bin` - Partition table with OTA support
- `ota_data_initial.bin` - Initial OTA data partition
- `light.bin` - Main application firmware (size: 0x176540 bytes)
- `flash_args_flat.txt` - Flash arguments for esptool
- `README_encrypted.md` - This file

## Link to Devin Run
https://app.devin.ai/sessions/f537687158644f48be3f9ccbf50b635d

## Requester
@ioR3sult
